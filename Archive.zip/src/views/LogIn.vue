<template>
<div class="login">
 <v-card class="elevation-12">

    <v-alert
      :value="isNotActive"
      type="error"
      transition="scale-transition"
    >
      This user account has not been activated yet :(
    </v-alert>



    <v-toolbar dark color="primary">
      <v-toolbar-title>LogIn</v-toolbar-title>
      <v-spacer></v-spacer>              
    </v-toolbar>
    <v-card-text>
      <v-form>
        <v-text-field v-model="username" prepend-icon="person" name="login" label="Enter your email" type="text"></v-text-field>
        <v-text-field v-model="password" id="password" prepend-icon="lock" name="password" label="Enter your password" type="password"></v-text-field>
      </v-form>
    </v-card-text>
    <v-card-actions>
      <v-layout align-center>
        <v-flex text-xs-center>
          <div><v-btn block color="success" @click="login" >LogIn</v-btn></div>
          <br>                
        </v-flex>
      </v-layout>
    </v-card-actions>

    <v-list v-if="errors && errors.length">
      <v-list-tile
        v-for="error in errors"
        :key="error.message"
      >
        <v-list-tile-content v-text="error.message">
          
        </v-list-tile-content>

      </v-list-tile>
    </v-list>

</v-card>
</div>
   
</template>

<script>
import { HTTP } from "../service";
import { EventBus } from "../event-bus.js";
export default {
  data() {
    return {
      message: "",
      username: "",
      password: "",
      errors: [],
      isNotActive: false,
      isLogInSuccess: false
    };
  },

  methods: {
    login() {
      this.errors = [];
      HTTP.get("login", {
        auth: {
          username: this.username,
          password: this.password
        }
      })
        .then(response => {
          if (response.data.activated === true) {
            this.isNotActive = false;
            localStorage.setItem("username", this.username);
            localStorage.setItem("password", this.password);
            localStorage.setItem("isLoggedIn", true);
            localStorage.setItem("userroles", JSON.stringify(response.data.roles));
            EventBus.$emit("logged", "User logged");
            this.$router.push("/");
          } else {
            this.isNotActive = true;
          }
        })
        .catch(e => {
          localStorage.clear();
          this.errors.push(e);
        });
    }
  }
};
</script>
<style scoped>
div.login {
  max-width: 500px;
  margin: auto;
}
</style>

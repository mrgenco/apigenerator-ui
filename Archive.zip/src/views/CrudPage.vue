<template>
  <div>
   
   
    <div >
        
       <v-btn color="info" @click.stop="dialog=true" style=" margin-left: 0; float: left;" >
            Create New
        </v-btn>  
        <v-btn :loading="isLoading" color="success" @click.stop="initialize()" style=" margin-left: 0; float: left;" >
            <v-icon>cached</v-icon>
        </v-btn>  
          <v-text-field  
                  style="float:right; width: 20%; margin-bottom: 1%;"    
                  color="green" 
                  v-model="search"
                  append-icon="search"
                  label="Search"
                  hide-details
         ></v-text-field>
    </div>
     
      
    <v-dialog v-model="dialog" max-width="500px">     
      <v-card>
        <v-card-title>
          <span class="headline">{{ formTitle }}</span>
        </v-card-title>
        <v-card-text>
          <v-container grid-list-md>
            <v-layout wrap>
              <v-flex >
                <v-text-field v-model="editedItem.code" label="Code"></v-text-field>
              </v-flex>
              <v-flex >
                <v-text-field v-model="editedItem.name" label="Name"></v-text-field>
              </v-flex>
              <v-flex >
                <v-text-field v-model="editedItem.cityCode" label="City Code"></v-text-field>
              </v-flex >
              <v-flex>
                <v-text-field v-model="editedItem.countryCode" label="Country Code"></v-text-field>
              </v-flex>          
            </v-layout>
          </v-container>
        </v-card-text>
        <v-card-actions>
          <v-spacer></v-spacer>
          <v-btn color="orange darken-3"  @click.native="close">Cancel</v-btn>
          <v-btn color="green darken-1"  @click.native="save">Save</v-btn>
        </v-card-actions>
      </v-card>
    </v-dialog>

    <v-data-table
      :headers="headers"
      :items="ports"
      class="elevation-1"
      :search="search"
      :loading="isLoading"
    >
      <v-progress-linear slot="progress" color="blue" indeterminate></v-progress-linear>
      <template slot="items" slot-scope="props">
        <td>{{ props.item.code }}</td>
        <td>{{ props.item.name }}</td>
        <td>{{ props.item.cityCode }}</td>
        <td>{{ props.item.countryCode }}</td>
        <td class="layout px-0">
          <v-btn icon class="mx-0" @click="editItem(props.item)">
            <v-icon color="info">edit</v-icon>
          </v-btn>
          <v-btn icon class="mx-0" @click="deleteItem(props.item)">
            <v-icon color="pink">delete</v-icon>
          </v-btn>
        </td>
      </template>
      <template slot="no-data">
        <p>Loading...</p>
      </template>
    </v-data-table>

     <v-list v-if="errors && errors.length">
        <v-list-tile
            v-for="error in errors"
            :key="error.message"
        >
            <v-list-tile-content v-text="error.message">
            
            </v-list-tile-content>
        </v-list-tile>
    </v-list>


   
  </div>
</template>

<!-- SCRIPT !-->
<script>
import { HTTP } from "../service";
export default {
  data: () => ({
    search: "",
    errors: [],
    isLoading: false,
    dialog: false,
    headers: [
      { text: "Code", value: "code" },
      { text: "Name", value: "name" },
      { text: "City Code", value: "cityCode" },
      { text: "Country Code", value: "countryCode" },
      { text: "Actions", value: "actions" }
    ],
    ports: [],
    editedIndex: -1,
    editedItem: {
      code: "",
      name: "",
      cityCode: "",
      countryCode: ""
    },
    defaultItem: {
      code: "",
      name: "",
      cityCode: "",
      countryCode: ""
    }
  }),

  computed: {
    formTitle() {
      return this.editedIndex === -1 ? "New Item" : "Edit Item";
    }
  },

  watch: {
    dialog(val) {
      val || this.close();
    }
  },

  created() {
    this.initialize();
  },

  methods: {
    initialize() {
      this.isLoading = true;
      HTTP.get("getPortList")
        .then(response => {
          this.ports = response.data;
          this.isLoading = false;
        })
        .catch(exception => {
          this.errors.push(exception);
          this.isLoading = false;
        });
    },

    editItem(item) {
      this.editedIndex = this.ports.indexOf(item);
      this.editedItem = Object.assign({}, item);
      this.dialog = true;
    },

    deleteItem(item) {
      if (confirm("Are you sure you want to delete this item?")) {
        const index = this.ports.indexOf(item);
        this.isLoading = true;
        HTTP.get("deletePortByCode?code=" + item.code)
          .then(response => {
            if (response) this.ports.splice(index, 1);
            this.isLoading = false;
          })
          .catch(exception => {
            this.errors.push(exception);
            this.isLoading = false;
          });
      }
    },

    close() {
      this.dialog = false;
      setTimeout(() => {
        this.editedItem = Object.assign({}, this.defaultItem);
        this.editedIndex = -1;
      }, 300);
    },

    save() {
      HTTP.post("savePort", this.editedItem)
        .then(response => {
          if (this.editedIndex > -1) {
            Object.assign(this.ports[this.editedIndex], this.editedItem);
          } else {
            this.ports.push(this.editedItem);
          }
        })
        .catch(exception => {
          this.errors.push(exception);
          this.isLoading = false;
        });
      this.close();
    }
  }
};
</script>
<!-- SCRIPT ENDS !-->

<style scoped>
h2 {
  color: white;
  margin: 5px;
}

td {
  font-size: 25;
}
</style>


<template>
<div class="signup">
    <v-card class="elevation-12">
              <v-toolbar dark color="primary">
                <v-toolbar-title>SignUp</v-toolbar-title>
             
              </v-toolbar>
              <v-card-text>
                <v-form>
                  <v-text-field  name="name" label="Name" type="text"></v-text-field>
                  <v-text-field  name="email" label="Email" type="email"></v-text-field>
                  <v-text-field  
                  v-model="password"
                  :append-icon="showPassword ? 'visibility_off' : 'visibility'" 
                  :type="showPassword ? 'text' : 'password'"
                  @click:append="showPassword = !showPassword"
                  name="Password" 
                  label="Password" >
                  </v-text-field>
                </v-form>
              </v-card-text>
              <v-card-actions>
                <v-btn block dark color="primary">Sign Up</v-btn>
                <br>
              </v-card-actions>
</v-card>
</div>
    
</template>

<script>
export default {
  data() {
    return {
      password: "",
      showPassword: false
    };
  }
};
</script>

<style scoped>
div.signup {
  max-width: 500px;
  margin: auto;
}
</style>

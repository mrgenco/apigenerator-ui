<template>
<div>
    

    <v-snackbar v-model="snack" :timeout="3000" :color="snackColor">
      {{ snackText }}
      <v-btn flat @click="snack = false">Close</v-btn>
    </v-snackbar>

     <v-data-table
    :headers="headers"
    :items="users"
    :loading="isLoading"
    hide-actions
    class="elevation-1"
    >
        <v-progress-linear slot="progress" color="blue" indeterminate></v-progress-linear>
        <template slot="items" slot-scope="props">
        <td>{{ props.item.username }}</td>
        <td>{{ props.item.email }}</td>
        <td>{{ props.item.roles[0]}}  <br> {{ props.item.roles[1] }} </td> 
        <td>
            <v-btn
            v-if="!props.item.activated"
            color="success"
            outline
            title="Activate User Account"
            @click="activateUser(props.item.email)">
            <v-icon  medium>  check_circle</v-icon>            
            </v-btn>

            <v-btn
            v-if="props.item.activated"
            color="error"
            outline
            title="Block User Account"
            @click="deactivateUser(props.item.email)">
            <v-icon medium>block</v-icon>
            
            </v-btn>       
        </td> 
        
        </template>
         <template slot="no-data">
            <p>Loading...</p>
        </template>
        
    </v-data-table>

    <v-list v-if="errors && errors.length">
        <v-list-tile
            v-for="error in errors"
            :key="error.message"
        >
            <v-list-tile-content v-text="error.message">
            
            </v-list-tile-content>
        </v-list-tile>
    </v-list>
    </div>
    
</template>

<script>
import { HTTP } from "../service";
export default {
  data() {
    return {
      users: [],
      isLoading: false,
      snack: false,
      snackColor: "",
      snackText: "",
      headers: [
        { text: "Username", value: "name" },
        { text: "Email", value: "email" },
        { text: "Roles", value: "roles" },
        { text: "Action", value: "action" }
      ],
      errors: []
    };
  },
  created() {
    this.errors = [];
    this.getAllUsers();
  },
  methods: {
    getAllUsers() {
      this.isLoading=true;
      HTTP.get("getAllUsers")
        .then(response => {
          this.users = response.data;
          this.isLoading=false;
        })
        .catch(exception => {
          this.errors.push(exception);
          this.isLoading=false;
        });
    },
    activateUser(email) {
      this.isLoading=true;
      HTTP.get("activateUser?email=" + email)
        .then(response => {
          this.isLoading=false;
          this.getAllUsers();
          this.showSnack(true,"success", email + " account is activated!");          
        })
        .catch(exception => {
          this.isLoading=false;
          this.errors.push(exception);
        });
    },
    deactivateUser(email) {
      this.isLoading=true;
      HTTP.get("deactivateUser?email=" + email)
        .then(response => {
          this.isLoading=false;
          this.getAllUsers();
          this.showSnack(true,"error", email + " account is blocked!");
        })
        .catch(exception => {
          this.isLoading=false;
          this.errors.push(exception);
        });
    },
    showSnack(snack, color, text){
        this.snack = snack;
        this.snackColor = color;
        this.snackText = text;
    }

  }
};
</script>

<style>
</style>

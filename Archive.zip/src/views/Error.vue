<template>
   <v-layout column align-center>
       <v-jumbotron color="error" dark>
            <v-container fill-height>
            <v-layout align-center>
                <v-flex text-xs-center>
                <h3 class="display-3">You are unauthorized to access this resource</h3>
                </v-flex>
            </v-layout>
            </v-container>
        </v-jumbotron>
   </v-layout>
</template>


<script>
export default {

}
</script>

<style>

</style>

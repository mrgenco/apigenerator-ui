<template>
   <v-layout column align-center>
    <h1>This is an about page</h1>
   </v-layout>
</template>


<script>
export default {

}
</script>

<style>

</style>

import Vue from 'vue'
import Router from 'vue-router'
import Home from './views/Home.vue'
import About from './views/About.vue'
import LogIn from './views/LogIn.vue'
import SignUp from './views/SignUp.vue'
import CrudPage from './views/CrudPage.vue'
import Error from './views/Error.vue'
import UserManagement from './views/UserManagement.vue'

Vue.use(Router)

const router = new Router({
  routes: [
    {
      path: '/',
      name: 'home',
      component: Home
    },
    {
      path: '/about',
      name: 'about',
      component: About
    },
    {
      path: '/login',
      name: 'login',
      component: LogIn
    },
    {
      path: '/signup',
      name: 'signup',
      component: SignUp
    },
    {
      path: '/crudpage',
      name: 'crudpage',
      component: CrudPage
    },
    {
      path: '/error',
      name: 'error',
      component: Error
    },
    {
      path: '/usermanagement',
      name: 'usermanagement',
      component: UserManagement
    }
  ]
})

router.beforeEach((to, from, next) => {
  var userroles = JSON.parse(localStorage.getItem("userroles"));
 
  if(userroles != null){
    if(to.path === '/crudpage'){
      if(userroles.some(role => role === 'ROLE_ADMIN')){
        next();
      } 
      else{
        next('/error');
      }   
    }
    else{
      next();
    }
  } else if(to.path !== '/crudpage'){
    next();
  } else{
    next('/error');
  }

  
  
})

// export router as default
export default router;
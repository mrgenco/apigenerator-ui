
<template>
    <div>
    <v-navigation-drawer
      :clipped="$vuetify.breakpoint.lgAndUp"
      v-model="drawer"
      fixed
      app
    >
    
  
      <v-list dense>
       <v-list-group  value="true">       
            <v-list-tile slot="activator">
              <v-list-tile-title>Admin Pages</v-list-tile-title>
            </v-list-tile>

            
            <v-list-tile v-if="hasAdminRole()" to="/usermanagement">
                <v-list-tile-action>
                </v-list-tile-action>
                <v-list-tile-content>
                  <v-list-tile-title>User Management</v-list-tile-title>
                </v-list-tile-content>
            </v-list-tile>
        </v-list-group>

        <v-list-group  value="true">       
              <v-list-tile slot="activator">
                <v-list-tile-title>User Pages</v-list-tile-title>
              </v-list-tile>

              <v-list-tile to="/logreport" >
                  <v-list-tile-action>
                  </v-list-tile-action>
                  <v-list-tile-content >
                    <v-list-tile-title>Log Report</v-list-tile-title>
                  </v-list-tile-content> 
              </v-list-tile>
              
              <v-list-tile to="/advancereport">
                  <v-list-tile-action>
                  </v-list-tile-action>
                  <v-list-tile-content>
                    <v-list-tile-title>Advance Report</v-list-tile-title>
                  </v-list-tile-content>
              </v-list-tile>

              <v-list-tile v-if="hasUserRole()" to="/crudpage" >
                <v-list-tile-action>
                </v-list-tile-action>
                <v-list-tile-content >
                  <v-list-tile-title>CRUD Example Page</v-list-tile-title>
                </v-list-tile-content> 
            </v-list-tile>
        </v-list-group>
      </v-list>

    
     
       
    </v-navigation-drawer>
   
    <v-toolbar
      :clipped-left="$vuetify.breakpoint.lgAndUp"
      color="blue darken-3"
      dark
      app
      fixed
    >
      <v-toolbar-title style="width: 300px" class="ml-0 pl-3">
          <v-avatar size="36px" tile>
          <img
            src="https://turkishairlines.ssl.cdn.sdlmedia.com/636621524287764399YM.png"
            alt="ClashRoyale"
          >
        </v-avatar>
        <v-toolbar-side-icon @click.stop="drawer = !drawer"></v-toolbar-side-icon>
        <span class="hidden-sm-and-down">BWSAdmin</span>
      </v-toolbar-title>      
      <v-spacer></v-spacer>
      <v-toolbar-items class="mt-1">
        <v-btn  flat to="/profile">{{ message }}</v-btn>
        <v-btn  v-if="isLoggedIn === true"  flat @click="logout">Logout</v-btn>
        <v-btn  v-if="isLoggedIn === false" flat to="/login">LOG IN</v-btn>
        <v-btn  v-if="isLoggedIn === false" flat to="/signup">SIGN UP</v-btn>
      </v-toolbar-items>
    </v-toolbar>
    </div>
</template>


<script>
import { EventBus } from "../event-bus.js";
export default {
  // Component name
  name: "Navbar",

  // Component data
  data: () => ({
    drawer: false,
    isLoggedIn: false,
    roles: [],
    message: "Welcome Guest!"
  }),

  // Component created hook in the component lifecycle
  created() {    
    this.getLoginInformation();
    this.getUserAndRoles();
    EventBus.$on("logged", () => {
       this.getLoginInformation();
       this.getUserAndRoles();
    });
  },

  methods: {

    getLoginInformation(){
      let user = localStorage.getItem("isLoggedIn");
      if (user) {
        this.isLoggedIn = true;
      } else {
        this.isLoggedIn = false;
      }
    },  
    getUserAndRoles() {
      if (this.isLoggedIn) {
        this.roles = JSON.parse(localStorage.getItem("userroles"));
        this.message = localStorage.getItem("username");
      } else {
        this.roles = [];
        this.message = "Welcome Guest!";
      }
    },
    hasAdminRole() {
      if (this.roles.some(role => role === "ROLE_ADMIN")) {
        return true;
      } else {
        return false;
      }
    },
    hasUserRole() {
      if (this.roles.some(role => role === "ROLE_USER")) {
        return true;
      } else {
        return false;
      }
    },
    logout() {
      localStorage.clear();
      this.isLoggedIn = false;
      this.message = "Welcome Guest!";
      this.roles = [];
      this.$router.push("/login");
    }
  }
};
</script>


<style>
.v-list--dense .v-list__tile {
  font-size: 18px;
}
</style>

<template>
  <div id="app">
    <Container></Container>
  </div>
</template>

<script>
import Container from './components/Container.vue'
export default {
  name: 'App',
  components:{
    Container
  }
}
</script>
<style>

</style>

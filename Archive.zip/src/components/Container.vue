<template>
  <v-app   id="inspire">    
    <Navbar></Navbar>      
    <v-content>
      <v-container fluid fill-height>
        <v-layout align-center justify-center>
        <v-flex md10>
          <transition name="component-fade" mode="out-in">

            <router-view></router-view>
           

          </transition>
        </v-flex>
        </v-layout>
      </v-container>
    </v-content>
  </v-app>
</template>

<script>
import Navbar from "../layout/Navbar.vue";

export default {
  name: "Container",
  components: {
    Navbar
  }
};
</script>


<style scoped>
.component-fade-enter-active,
.component-fade-leave-active {
  transition: opacity 0.3s ease;
}
.component-fade-enter, .component-fade-leave-to
  /* .component-fade-leave-active below version 2.1.8 */ {
  opacity: 0;
}

.bounce-enter-active {
  animation: bounce-in 0.5s;
}
.bounce-leave-active {
  animation: bounce-in 0.5s reverse;
}
@keyframes bounce-in {
  0% {
    transform: scale(0);
  }
  50% {
    transform: scale(1.5);
  }
  100% {
    transform: scale(1);
  }
}
</style>
